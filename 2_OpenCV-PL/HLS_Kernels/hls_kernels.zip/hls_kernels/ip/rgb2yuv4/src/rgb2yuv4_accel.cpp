#include "hls_stream.h"
#include "ap_int.h"
#include "common/xf_common.hpp"
#include "common/xf_utility.hpp"
#include "imgproc/xf_cvt_color.hpp"
#include "imgproc/xf_cvt_color_1.hpp"
#include "imgproc/xf_channel_combine.hpp"

#define DATA_WIDTH 24

#define WIDTH 1920
#define HEIGHT 1080

#define NPC XF_NPPC1

template <int W, int TYPE, int ROWS, int COLS, int NPPC>
void axis2xfMat (hls::stream<ap_axiu<W, 1, 1, 1> >& AXI_video_strm, xf::cv::Mat<TYPE, ROWS, COLS, NPPC>& img) {
    ap_axiu<W, 1, 1, 1> axi;

    const int m_pix_width = XF_PIXELWIDTH(TYPE, NPPC) * XF_NPIXPERCYCLE(NPPC);

    int rows = img.rows;
    int cols = img.cols >> XF_BITSHIFT(NPPC);

    assert(img.rows <= ROWS);
    assert(img.cols <= COLS);

loop_row_axi2mat:
    for (int i = 0; i < rows; i++) {
    loop_col_zxi2mat:
        for (int j = 0; j < cols; j++) {
#pragma HLS loop_flatten off
#pragma HLS pipeline II=1

            AXI_video_strm.read(axi);
            img.write(i*rows + j, axi.data(m_pix_width - 1, 0));
        }
    }
}

template <int W, int TYPE, int ROWS, int COLS, int NPPC>
void xfMat2axis(xf::cv::Mat<TYPE, ROWS, COLS, NPPC>& img, hls::stream<ap_axiu<W, 1, 1, 1> >& dst) {
    ap_axiu<W, 1, 1, 1> axi;

    int rows = img.rows;
    int cols = img.cols >> XF_BITSHIFT(NPPC);

    assert(img.rows <= ROWS);
    assert(img.cols <= COLS);

    const int m_pix_width = XF_PIXELWIDTH(TYPE, NPPC) * XF_NPIXPERCYCLE(NPPC);

loop_row_mat2axi:
    for (int i = 0; i < rows; i++) {
    loop_col_mat2axi:
        for (int j = 0; j < cols; j++) {
#pragma HLS loop_flatten off
#pragma HLS pipeline II = 1

            if ((j == cols-1) && (i == rows-1)) {
                axi.last = 1;
            } else {
                axi.last = 0;
            }

            axi.data = 0;
            axi.data(m_pix_width - 1, 0) = img.read(i*rows + j);
            axi.keep = -1;
            dst.write(axi);
        }
    }
}

void rgb2yuv4_accel(hls::stream<xf::cv::ap_axiu<DATA_WIDTH,1,1,1>>& src,
                    hls::stream<xf::cv::ap_axiu<DATA_WIDTH,1,1,1>>& dst,
                    int rows, int cols) {
    #pragma HLS INTERFACE axis register both port=src
    #pragma HLS INTERFACE axis register both port=dst
    #pragma HLS INTERFACE s_axilite port=rows
    #pragma HLS INTERFACE s_axilite port=cols
    #pragma HLS INTERFACE s_axilite port=return

    xf::cv::Mat<XF_8UC3, HEIGHT, WIDTH, NPC> src_mat(rows, cols);
    xf::cv::Mat<XF_8UC3, HEIGHT, WIDTH, NPC> dst_mat(rows, cols);
    xf::cv::Mat<XF_8UC1, HEIGHT, WIDTH, NPC> dst0_mat(rows, cols);
    xf::cv::Mat<XF_8UC1, HEIGHT, WIDTH, NPC> dst1_mat(rows, cols);
    xf::cv::Mat<XF_8UC1, HEIGHT, WIDTH, NPC> dst2_mat(rows, cols);

    #pragma HLS DATAFLOW

    axis2xfMat<DATA_WIDTH, XF_8UC3, HEIGHT, WIDTH, NPC>(src, src_mat);

    xf::cv::rgb2yuv4<XF_8UC3, XF_8UC1, HEIGHT, WIDTH, NPC>(src_mat, dst0_mat, dst1_mat, dst2_mat);
    xf::cv::merge<XF_8UC1, XF_8UC3, HEIGHT, WIDTH, NPC>(dst0_mat, dst1_mat, dst2_mat, dst_mat);

    xfMat2axis<DATA_WIDTH, XF_8UC3, HEIGHT, WIDTH, NPC>(dst_mat, dst);
}
